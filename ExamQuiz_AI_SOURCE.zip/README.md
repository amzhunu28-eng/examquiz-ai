# ExamQuiz AI — Gemini Free Tier

ExamQuiz AI turns study files or YouTube videos with available captions into exam-oriented MCQs, then scores the test, explains answers, analyses topics, and creates mistake-repair practice.

## AI provider
This version uses the Google Gemini API instead of OpenAI. Google provides a free tier for selected Gemini API models, subject to model-specific rate limits. No OpenAI API key is required.

Set `GEMINI_API_KEY` as a secret environment variable. The default model is `gemini-3.8-flash`; you can change it with `GEMINI_MODEL` if your Google AI Studio account exposes another free-tier model.

## Render
Deploy as a Docker Web Service. Set `GEMINI_API_KEY`, leave `GEMINI_MODEL` as `gemini-3.8-flash`, and deploy.

## Features
- PDF/DOCX/PPTX/XLSX/TXT/CSV/image ingestion
- YouTube URL -> transcript -> MCQs
- Transcript language selection
- Exam styles and difficulty
- 1-100 questions
- Negative marking
- Score, accuracy, topic analysis
- Answer review with explanations/source references
- AI-generated mistake-repair quiz

## Important
The Gemini API free tier is subject to Google's current rate limits and availability. Hosting is separate from AI usage; this project uses a Render free service configuration, subject to Render's current free-plan limits.
