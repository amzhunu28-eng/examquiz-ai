# ExamQuiz AI — Final Web App

ExamQuiz AI turns study files **or YouTube videos with available captions** into exam-oriented MCQs. It supports quiz scoring, negative marking, explanations/source timestamps, topic analysis, and mistake-based practice.

## Public deployment
This is a server-backed web application, not a static HTML file. The included `render.yaml` and `Dockerfile` are ready for a Render Web Service. Render supports FastAPI/Docker web services and provides a public `onrender.com` URL after deployment. citeturn0search0turn0search2

1. Put this project in a GitHub repository.
2. In Render, create a **Web Service** from that repository (or use the Blueprint `render.yaml`).
3. Set `OPENAI_API_KEY` as a secret environment variable.
4. Deploy.
5. Open the generated `https://....onrender.com` URL.

Render requires the service to listen on `0.0.0.0`; this project uses the `PORT` environment variable for that. citeturn0search0

## Features
- PDF/DOCX/PPTX/XLSX/TXT/CSV/image ingestion
- YouTube URL → transcript → MCQs
- Preferred transcript language, e.g. `en,hi`
- Exam styles and difficulty
- 1–100 questions
- Negative marking
- Score, accuracy, topic analysis
- Full answer review with explanations and source/timestamp references
- AI-generated mistake-repair quiz
- Server health/API configuration indicator

## YouTube limitation
YouTube transcript extraction depends on captions being available and on the transcript service continuing to work with YouTube. The Python `youtube-transcript-api` project supports manually created and automatically generated transcripts, but notes that the underlying YouTube interface is undocumented and can change. citeturn1search6turn1search9

## Local
Copy `.env.example` to `.env`, set `OPENAI_API_KEY`, then run `run.bat` or `./run.sh`. Open `http://127.0.0.1:8000`. Never put the OpenAI key in browser JavaScript.
