@echo off
cd /d "%~dp0"
if not exist .venv python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
findstr /C:"your_api_key_here" .env >nul
if %errorlevel%==0 (
  echo.
  echo Add your OPENAI_API_KEY to .env, save it, then run run.bat again.
  pause
  exit /b 0
)
python -m uvicorn app:app --host 127.0.0.1 --port 8000
