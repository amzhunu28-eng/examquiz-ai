#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if [ ! -f .env ]; then cp .env.example .env; echo "Created .env. Add your GEMINI_API_KEY, then run this script again."; exit 0; fi
python -m uvicorn app:app --host 127.0.0.1 --port 8000
