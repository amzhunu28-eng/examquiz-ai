import os, io, json, re, uuid
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from pypdf import PdfReader
from docx import Document
from pptx import Presentation
from openpyxl import load_workbook
from PIL import Image
import pytesseract
try:
    from youtube_transcript_api import YouTubeTranscriptApi
except ImportError:
    YouTubeTranscriptApi = None
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / ".env")

app = FastAPI(title="ExamQuiz AI", version="6.0")
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")

API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna").strip()
MAX_MB = int(os.getenv("MAX_UPLOAD_MB", "40"))
MOCK_AI = os.getenv("MOCK_AI", "false").lower() == "true"
client = OpenAI(api_key=API_KEY) if (API_KEY and OpenAI is not None) else None

SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {"questions": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "properties": {
            "id": {"type": "string"},
            "question": {"type": "string"},
            "options": {"type": "array", "items": {"type": "string"}, "minItems": 4, "maxItems": 4},
            "correct_index": {"type": "integer", "minimum": 0, "maximum": 3},
            "explanation": {"type": "string"},
            "topic": {"type": "string"},
            "source": {"type": "string"}
        },
        "required": ["id", "question", "options", "correct_index", "explanation", "topic", "source"]
    }}},
    "required": ["questions"]
}



def youtube_video_id(url):
    value = url.strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", value):
        return value
    parsed = urlparse(value)
    host = (parsed.hostname or "").lower()
    if host in {"youtu.be", "www.youtu.be"}:
        candidate = parsed.path.strip("/").split("/")[0]
        if re.fullmatch(r"[A-Za-z0-9_-]{11}", candidate):
            return candidate
    if host.endswith("youtube.com"):
        q = parse_qs(parsed.query)
        candidate = q.get("v", [""])[0]
        if re.fullmatch(r"[A-Za-z0-9_-]{11}", candidate):
            return candidate
        parts = parsed.path.strip("/").split("/")
        if len(parts) >= 2 and parts[0] in {"shorts", "embed", "live"} and re.fullmatch(r"[A-Za-z0-9_-]{11}", parts[1]):
            return parts[1]
    raise ValueError("Enter a valid YouTube video URL or 11-character video ID.")

def fetch_youtube_text(url, language="en"):
    if YouTubeTranscriptApi is None:
        raise RuntimeError("YouTube transcript support is not installed on this server.")
    video_id = youtube_video_id(url)
    languages = [x.strip() for x in language.split(",") if x.strip()] or ["en"]
    api = YouTubeTranscriptApi()
    transcript = api.list(video_id)
    try:
        selected = transcript.find_transcript(languages)
    except Exception:
        # Prefer any available generated/manual transcript if the requested language is absent.
        available = list(transcript)
        if not available:
            raise ValueError("No transcript/captions are available for this video.")
        selected = available[0]
    fetched = selected.fetch()
    lines = []
    for item in fetched:
        text = re.sub(r"\s+", " ", getattr(item, "text", "")).strip()
        if not text:
            continue
        start = float(getattr(item, "start", 0) or 0)
        mm, sec = divmod(int(start), 60)
        hh, mm = divmod(mm, 60)
        stamp = f"{hh:02d}:{mm:02d}:{sec:02d}" if hh else f"{mm:02d}:{sec:02d}"
        lines.append(f"[Timestamp {stamp}] {text}")
    if not lines:
        raise ValueError("The video transcript is empty.")
    return "\n".join(lines), video_id, getattr(selected, "language_code", language)

def text_pdf(data):
    reader = PdfReader(io.BytesIO(data))
    pages = []
    for i, page in enumerate(reader.pages, 1):
        text = page.extract_text() or ""
        if text.strip():
            pages.append(f"[Page {i}]\n{text}")
    return "\n\n".join(pages)


def extract(data, name):
    ext = Path(name).suffix.lower()
    if ext == ".pdf":
        text = text_pdf(data)
        if len(text.strip()) >= 100:
            return text, "pdf-text"
        raise ValueError("This PDF appears to be scanned/image-only. This version needs selectable PDF text; OCR for scanned PDFs is not enabled on the server yet.")
    if ext == ".docx":
        doc = Document(io.BytesIO(data))
        parts = []
        for i, p in enumerate(doc.paragraphs, 1):
            if p.text.strip():
                parts.append(f"[Paragraph {i}] {p.text}")
        for ti, table in enumerate(doc.tables, 1):
            for row in table.rows:
                parts.append(f"[Table {ti}] " + " | ".join(c.text for c in row.cells))
        return "\n".join(parts), "docx"
    if ext == ".pptx":
        prs = Presentation(io.BytesIO(data))
        parts = []
        for i, slide in enumerate(prs.slides, 1):
            texts = []
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    texts.append(shape.text)
            if texts:
                parts.append(f"[Slide {i}]\n" + "\n".join(texts))
        return "\n\n".join(parts), "pptx"
    if ext == ".xlsx":
        wb = load_workbook(io.BytesIO(data), data_only=True, read_only=True)
        parts = []
        for ws in wb.worksheets:
            parts.append(f"[Sheet: {ws.title}]")
            for row in ws.iter_rows(values_only=True):
                vals = [str(v) for v in row if v is not None]
                if vals:
                    parts.append(" | ".join(vals))
        return "\n".join(parts), "xlsx"
    if ext in (".txt", ".csv"):
        return data.decode("utf-8-sig", errors="replace"), ext[1:]
    if ext in (".png", ".jpg", ".jpeg", ".webp"):
        try:
            image = Image.open(io.BytesIO(data))
            text = pytesseract.image_to_string(image)
            if len(text.strip()) < 30:
                raise ValueError("OCR could not read enough text from the image.")
            return text, "ocr-image"
        except ValueError:
            raise
        except Exception:
            raise ValueError("Image OCR is unavailable. Install Tesseract OCR on the machine running the app.")
    if ext == ".doc":
        raise ValueError("Legacy .doc is not supported directly. Save it as .docx or PDF.")
    raise ValueError("Unsupported file type. Use PDF, DOCX, PPTX, XLSX, TXT, CSV, PNG, JPG or WEBP.")


def chunks(text, size=26000):
    markers = re.compile(r"(?=\[(?:Page|Slide|Sheet|Paragraph|Table)[^\]]*\])")
    sections = [x.strip() for x in markers.split(text) if x.strip()]
    if not sections:
        sections = [text]
    result, current = [], ""
    for section in sections:
        if len(current) + len(section) + 2 > size and current:
            result.append(current)
            current = ""
        current += ("\n\n" if current else "") + section
    if current:
        result.append(current)
    return result or [text]


def mock_questions(material, n):
    first = re.sub(r"\s+", " ", material).strip()[:100]
    return [{
        "id": str(uuid.uuid4()),
        "question": f"Which statement is directly supported by the uploaded material?",
        "options": [first or "The material contains no text", "The material is unavailable", "The material was not uploaded", "None of the above"],
        "correct_index": 0,
        "explanation": "Development-test question generated in MOCK_AI mode from the uploaded text.",
        "topic": "Mock test",
        "source": "Development test"
    } for _ in range(min(n, 3))]


def generate(material, n, difficulty, style):
    if MOCK_AI:
        return mock_questions(material, n)
    if not client:
        raise RuntimeError("OPENAI_API_KEY is not configured. Add it to the server's .env file.")
    prompt = f"""You are a rigorous competitive-exam question setter.
Create up to {n} MCQs using ONLY the supplied source material.
Difficulty: {difficulty}. Style: {style}.
Requirements:
1. Exactly four plausible options and exactly one correct answer.
2. No outside facts. If the source cannot support an answer, do not ask it.
3. Avoid duplicates and cover different topics when the source permits.
4. Explanations must be supported by the source.
5. Source must identify page, slide, sheet, paragraph, or section where possible.
6. Return fewer questions rather than inventing content.
Return only the supplied JSON schema.

SOURCE MATERIAL:
{material}"""
    response = client.responses.create(
        model=MODEL,
        input=prompt,
        text={"format": {"type": "json_schema", "name": "exam_quiz", "strict": True, "schema": SCHEMA}}
    )
    return json.loads(response.output_text)["questions"]


def validate(questions):
    clean = []
    for q in questions:
        if not isinstance(q, dict):
            continue
        opts = q.get("options")
        idx = q.get("correct_index")
        if not isinstance(q.get("question"), str) or not isinstance(opts, list) or len(opts) != 4:
            continue
        if not isinstance(idx, int) or not 0 <= idx < 4:
            continue
        if any(not isinstance(o, str) or not o.strip() for o in opts):
            continue
        if len({o.strip().lower() for o in opts}) != 4:
            continue
        clean.append(q)
    return clean


@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "static" / "index.html").read_text(encoding="utf-8")


@app.get("/health")
def health():
    return {"ok": True, "ai_configured": bool(client), "model": MODEL, "mock_ai": MOCK_AI}


@app.post("/api/generate")
async def api_generate(file: UploadFile = File(...), count: int = 10, difficulty: str = "Mixed", style: str = "Mixed exam-oriented"):
    if count < 1 or count > 100:
        raise HTTPException(400, "Question count must be between 1 and 100.")
    if not file.filename:
        raise HTTPException(400, "No filename supplied.")
    if not client and not MOCK_AI:
        raise HTTPException(503, "AI is not configured on this server. Add OPENAI_API_KEY to .env and restart the server.")
    data = await file.read()
    if len(data) > MAX_MB * 1024 * 1024:
        raise HTTPException(413, f"File is larger than {MAX_MB} MB.")
    try:
        text, kind = extract(data, file.filename)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if len(text.strip()) < 50:
        raise HTTPException(400, "Not enough readable content was found in this file.")

    questions, seen = [], set()
    parts = chunks(text)
    remaining = count
    for part in parts:
        if remaining <= 0:
            break
        target = min(max(2, remaining), 12)
        try:
            batch = validate(generate(part, target, difficulty, style))
        except Exception as e:
            raise HTTPException(502, f"AI generation failed: {e}")
        for q in batch:
            key = re.sub(r"\W+", " ", q["question"].lower()).strip()
            if key and key not in seen:
                seen.add(key)
                questions.append(q)
                remaining -= 1
                if remaining <= 0:
                    break

    if not questions:
        raise HTTPException(502, "No valid questions were generated. Try a different document or settings.")
    return {"quiz_id": str(uuid.uuid4()), "filename": file.filename, "file_type": kind, "questions": questions}


@app.post("/api/generate-youtube")
async def api_generate_youtube(payload: dict):
    if not client and not MOCK_AI:
        raise HTTPException(503, "AI is not configured on this server. Add OPENAI_API_KEY and restart the server.")
    url = str(payload.get("url", "")).strip()
    language = str(payload.get("language", "en")).strip() or "en"
    count = int(payload.get("count", 10))
    difficulty = str(payload.get("difficulty", "Mixed"))
    style = str(payload.get("style", "Mixed exam-oriented"))
    if not url:
        raise HTTPException(400, "Paste a YouTube video URL.")
    if count < 1 or count > 100:
        raise HTTPException(400, "Question count must be between 1 and 100.")
    try:
        text, video_id, used_language = fetch_youtube_text(url, language)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(502, f"Could not retrieve the YouTube transcript: {e}")
    questions, seen = [], set()
    remaining = count
    for part in chunks(text):
        if remaining <= 0:
            break
        target = min(max(2, remaining), 12)
        try:
            batch = validate(generate(part, target, difficulty, style))
        except Exception as e:
            raise HTTPException(502, f"AI generation failed: {e}")
        for q in batch:
            key = re.sub(r"\W+", " ", q["question"].lower()).strip()
            if key and key not in seen:
                seen.add(key)
                questions.append(q)
                remaining -= 1
                if remaining <= 0:
                    break
    if not questions:
        raise HTTPException(502, "No valid questions were generated from the transcript.")
    return {"quiz_id": str(uuid.uuid4()), "video_id": video_id, "language": used_language, "questions": questions}

@app.post("/api/mistakes")
async def api_mistakes(payload: dict):
    if not client and not MOCK_AI:
        raise HTTPException(503, "AI is not configured on this server.")
    wrong = payload.get("wrong_questions", [])
    if not wrong:
        raise HTTPException(400, "No mistakes supplied.")
    material = "\n\n".join(
        f"Topic: {q.get('topic', '')}\nQuestion: {q.get('question', '')}\nExplanation: {q.get('explanation', '')}\nSource: {q.get('source', '')}"
        for q in wrong
    )
    try:
        questions = validate(generate(material, min(int(payload.get("count", 10)), 30), "Moderate", "Mistake-repair"))
    except Exception as e:
        raise HTTPException(502, f"AI generation failed: {e}")
    return {"questions": questions}
